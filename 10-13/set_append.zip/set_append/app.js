var itemsContainer = document.getElementById("items-container")

var emptyH1 = document.createElement("h1")


emptyH1.setAttribute("class", "redText")


var auth = false;

if (auth) {
  emptyH1.textContent = "You are logged in!!!!"
} else {
  emptyH1.textContent = "You are not logged in"
}


console.log(emptyH1)
// itemsContainer.appendChild(emptyH1)

document.body.children[0].appendChild(emptyH1)
